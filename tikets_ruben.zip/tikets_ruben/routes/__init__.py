from flask import Flask

def register_blueprints(app: Flask):
    from .main_routes import main_bp
    from .dashboard_routes import dashboard_bp
    from .project_routes import project_bp
    from .tiket_routes import tiket_bp
    from .personal_routes import personal_bp
    from .agenda_routes import agenda_bp
    from .weekly_report_routes import weekly_bp
    from .agenda_predictiva import para_hoy_bp
    from .paquete_routes import paquete_bp
    from .resumen import resumen_bp
    from .api import api_bp
    from .growth_routes import growth_bp
    from routes.checklist import checklist_bp
    from routes.tiket_visual import visual_bp
    from routes.tiket_edit import edit_bp
    from routes.naming_ai import naming_bp

    # 🔹 Registrar todos los blueprints
    app.register_blueprint(main_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(project_bp)
    app.register_blueprint(tiket_bp)
    app.register_blueprint(personal_bp)
    app.register_blueprint(agenda_bp)
    app.register_blueprint(paquete_bp)
    app.register_blueprint(resumen_bp)
    app.register_blueprint(api_bp)
    app.register_blueprint(growth_bp)
    app.register_blueprint(weekly_bp)
    app.register_blueprint(para_hoy_bp)
    app.register_blueprint(checklist_bp)
    app.register_blueprint(visual_bp)
    app.register_blueprint(edit_bp)
    app.register_blueprint(naming_bp)

    # ===================================================
    # 🧭 CONTEXT PROCESSOR GLOBAL: Subtareas cerradas hoy
    # ===================================================
    from datetime import datetime
    import pytz
    from models import get_db
    from flask import current_app

    @app.context_processor
    def global_subtareas_cerradas_hoy():
        """Envía el conteo diario de subtareas cerradas a todas las plantillas"""
        try:
            tz = pytz.timezone("America/Monterrey")
            hoy = datetime.now(tz).date()
            db = get_db(current_app)
            cur = db.cursor()
            cur.execute("""
                SELECT COUNT(*) AS cerradas
                FROM subtasks
                WHERE DATE(fecha_cierre) = ? AND cerrado = 1;
            """, (hoy,))
            row = cur.fetchone()
            cerradas = row["cerradas"] if row else 0
        except Exception as e:
            print("⚠️ Error al calcular subtareas cerradas hoy:", e)
            cerradas = 0

        # 👇 estará disponible en todas las plantillas
        return dict(subtareas_cerradas_hoy=cerradas)
