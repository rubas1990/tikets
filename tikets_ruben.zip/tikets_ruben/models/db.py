# models/db.py
import sqlite3
from flask import g
from werkzeug.security import generate_password_hash

# ---------------------------------------------------------
# 1️⃣ Conexión a la base de datos
# ---------------------------------------------------------
def get_db(app):
    """Abre conexión SQLite si no existe en este contexto Flask."""
    if 'db' not in g:
        g.db = sqlite3.connect(app.config['DATABASE'])
        g.db.row_factory = sqlite3.Row
    return g.db


def close_db(e=None):
    """Cierra la conexión activa (si existe)."""
    db = g.pop('db', None)
    if db is not None:
        db.close()


# ---------------------------------------------------------
# 2️⃣ Inicialización y creación de tablas
# ---------------------------------------------------------
def init_db(app):
    """Inicializa la base de datos: crea tablas si no existen."""
    app.teardown_appcontext(close_db)

    with app.app_context():
        db = get_db(app)
        cur = db.cursor()

        # 🧱 Tabla usuarios
        cur.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL CHECK (role IN ('admin','user'))
            );
        """)

        # 🧱 Tabla proyectos
        cur.execute("""
            CREATE TABLE IF NOT EXISTS projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL,
                numero_de_queja TEXT UNIQUE NOT NULL,
                sitio TEXT NOT NULL,
                prioridad TEXT NOT NULL,
                status TEXT NOT NULL CHECK (status IN ('Planeado','Detenido','Trabajando','Cerrado')),
                fecha_apertura TEXT NOT NULL,
                fecha_cierre TEXT,
                comentarios TEXT,
                ahorro REAL DEFAULT 0,
                gasto REAL DEFAULT 0
            );
        """)

        # 🧱 Tabla subtareas
        cur.execute("""
            CREATE TABLE IF NOT EXISTS subtasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER NOT NULL,
                numero_de_queja TEXT NOT NULL,
                nombre_subtarea TEXT NOT NULL,
                cerrado INTEGER NOT NULL DEFAULT 0,
                fecha_apertura TEXT NOT NULL,
                fecha_cierre TEXT,
                comentarios TEXT DEFAULT '',
                tiempo_objetivo_horas REAL,
                prioridad TEXT,
                tiempo_objetivo REAL DEFAULT 0,
                categoria TEXT,
                FOREIGN KEY (project_id) REFERENCES projects(id)
            );
        """)


        # 🧱 Tabla historial
        cur.execute("""
            CREATE TABLE IF NOT EXISTS historial (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tipo TEXT NOT NULL,
                ref_id INTEGER NOT NULL,
                fecha TEXT NOT NULL,
                accion TEXT NOT NULL,
                detalle TEXT NOT NULL,
                usuario TEXT NOT NULL
            );
        """)

        # 🧱 Tabla de registro de tiempo
        cur.execute("""
            CREATE TABLE IF NOT EXISTS project_tiempo (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER NOT NULL,
                inicio TEXT NOT NULL,
                fin TEXT,
                duracion_horas REAL,
                FOREIGN KEY (project_id) REFERENCES projects(id)
            );
        """)

        # 🧱 NUEVA TABLA: tareas personales
        cur.execute("""
            CREATE TABLE IF NOT EXISTS personal_tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fecha TEXT NOT NULL,
                tipo TEXT NOT NULL CHECK(tipo IN ('Proyecto', 'Personal')),
                numero_tarea TEXT NOT NULL,
                descripcion TEXT,
                project_id INTEGER,
                username TEXT NOT NULL,
                FOREIGN KEY(project_id) REFERENCES projects(id)
            );
        """)

        db.commit()

        # 👤 Usuarios por defecto
        cur.execute("SELECT COUNT(*) AS c FROM users;")
        if cur.fetchone()['c'] == 0:
            cur.execute("INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
                        ("admin", generate_password_hash("admin123"), "admin"))
            cur.execute("INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)",
                        ("usuario", generate_password_hash("usuario123"), "user"))
            db.commit()


        # 🧱 NUEVA TABLA: tareas personales
        cur.execute("""
            CREATE TABLE IF NOT EXISTS personal_tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fecha TEXT NOT NULL,
                tipo TEXT NOT NULL CHECK(tipo IN ('Proyecto', 'Personal')),
                numero_tarea TEXT NOT NULL,
                descripcion TEXT,
                project_id INTEGER,
                username TEXT NOT NULL,
                FOREIGN KEY(project_id) REFERENCES projects(id)
            );
        """)

        # 🧱 NUEVAS TABLAS: seguimiento de hábitos
        cur.execute("""
            CREATE TABLE IF NOT EXISTS habits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                nombre TEXT NOT NULL,
                posicion INTEGER NOT NULL CHECK(posicion BETWEEN 1 AND 5)
            );
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS habit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                habit_id INTEGER NOT NULL,
                fecha TEXT NOT NULL,
                completado INTEGER DEFAULT 0,
                FOREIGN KEY (habit_id) REFERENCES habits(id)
            );
        """)

        db.commit()


        # 🧠 Tabla de estado emocional
        cur.execute("""
            CREATE TABLE IF NOT EXISTS emocional_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fecha TEXT NOT NULL,
                username TEXT NOT NULL,
                categoria TEXT,
                horas_trabajadas REAL DEFAULT 0,
                tareas_seguidas INTEGER DEFAULT 0,
                nivel_fatiga TEXT,
                estado_emocional TEXT,
                mensaje TEXT
            );
        """)


        # 🕒 Tabla de tiempos de subtareas
        cur.execute("""
            CREATE TABLE IF NOT EXISTS subtask_tiempo (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                subtask_id INTEGER NOT NULL,
                username TEXT NOT NULL,
                inicio TEXT NOT NULL,
                fin TEXT,
                duracion_min REAL,
                FOREIGN KEY (subtask_id) REFERENCES subtasks(id)
            );
        """)



        # 🧱 Tabla de Resultados Clave (KR / OKR)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS okr_kr (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                categoria TEXT NOT NULL,
                kr TEXT NOT NULL,
                activo INTEGER DEFAULT 1
            );
        """)
