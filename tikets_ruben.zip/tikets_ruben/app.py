# app.py
# -------------------------------
# Punto de entrada de la aplicación Flask:
# - Configura la app
# - Inicializa la base de datos si no existe
# - Registra blueprints de auth y rutas de negocio (modulares)
# - Define un filtro Jinja para formatear fechas
# - Lanza un hilo automático que cierra proyectos activos a las 17:06 (hora Monterrey)

from flask import Flask, session  # 👈 Agregamos session aquí
from models import init_db, get_db, registrar_fin_trabajo
from models.personal import get_current_activity  # 👈 Importa la función que devuelve la actividad actual
from auth import auth_bp
from routes import register_blueprints
import threading
import time
from datetime import datetime
import pytz
from routes.reports_routes import reports_bp


def create_app():
    """Inicializa y configura la aplicación Flask."""
    app = Flask(__name__)
    app.config["BUILD_ID"] = int(datetime.now().timestamp())
    app.config['SECRET_KEY'] = 'cambia-esta-clave-en-produccion'

    # 📂 Ruta absoluta a la base (garantiza conexión)
    import os
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    app.config['DATABASE'] = os.path.join(BASE_DIR, 'soporte.db')
    print(f"[debug] 🧱 Usando base de datos: {app.config['DATABASE']}")

    # Inicializa DB (crea tablas y datos semilla si no existen)
    init_db(app)

    # 🔹 Registrar blueprints
    app.register_blueprint(auth_bp)
    register_blueprints(app)
    app.register_blueprint(reports_bp)

    # 🔹 Filtro Jinja para formatear fechas legibles
    @app.template_filter('fmt_dt')
    def fmt_dt(value):
        if not value:
            return ''
        return value.replace('T', ' ').split('.')[0]

    # 🧠 Inyectar actividad actual en todas las vistas (navbar, etc.)
    @app.context_processor
    def inject_current_activity():
        """Inyecta la actividad actual al contexto global (navbar, etc)."""
        username = session.get("username")
        if not username:
            return dict(current_activity=None)

        actividad = get_current_activity(app, username)
        return dict(current_activity=actividad)

    return app




def cerrar_proyectos_fuera_de_horario(app):
    """Revisa cada minuto si ya son las 17:06 y cierra proyectos activos una sola vez por día."""
    from flask import current_app
    import pytz

    ultima_ejecucion = None  # Guarda la fecha del último cierre

    with app.app_context():  # ✅ importante: usa contexto de Flask
        while True:
            try:
                tz = pytz.timezone("America/Monterrey")
                ahora = datetime.now(tz)
                hora_actual = ahora.strftime("%H:%M")
                fecha_actual = ahora.date()

                # Solo ejecuta una vez al día exactamente a las 17:06
                if hora_actual == "17:06" and ultima_ejecucion != fecha_actual:
                    db = get_db(current_app)
                    cur = db.cursor()
                    cur.execute("SELECT id, nombre FROM projects WHERE status='Trabajando';")
                    activos = cur.fetchall()

                    if activos:
                        for a in activos:
                            cur.execute("UPDATE projects SET status='Detenido' WHERE id=?;", (a['id'],))
                            registrar_fin_trabajo(current_app, a['id'])
                        db.commit()
                        print(f"🔔 {len(activos)} proyecto(s) cambiado(s) a 'Detenido' automáticamente por horario.")
                    else:
                        print("✅ Ningún proyecto en estado 'Trabajando' al cierre automático.")

                    ultima_ejecucion = fecha_actual  # Marca que ya se ejecutó hoy

                # Espera 60 segundos antes de volver a revisar
                time.sleep(60)

            except Exception as e:
                print(f"⚠️ Error en tarea automática: {e}")
                time.sleep(60)



from datetime import datetime
import requests

def revisar_reporte_semana():
    hoy = datetime.now()
    # Viernes a las 17:00 PM (+- 10 min)
    if hoy.weekday() == 4 and hoy.hour == 17:
        try:
            requests.get("http://127.0.0.1:5000/weekly/generate")
        except:
            print("[X] No se pudo generar reporte semanal")

# Ejecutar cada vez que se visita /
revisar_reporte_semana()

if __name__ == '__main__':
    app = create_app()

    # 🔹 Lanzar hilo en segundo plano con contexto Flask
    threading.Thread(target=cerrar_proyectos_fuera_de_horario, args=(app,), daemon=True).start()

    # Ejecutar servidor Flask
    app.run(debug=True, port=70, host="0.0.0.0")
